# Question 4: Formatting
temperature = 32.6

print("The temperature today is: {:.3f} degrees Celsius".format(temperature))